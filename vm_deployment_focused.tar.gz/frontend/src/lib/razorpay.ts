// Razorpay integration service
import Razorpay from 'razorpay';

// Razorpay configuration
const RAZORPAY_KEY_ID = 'rzp_test_RXeqbfnAyzjhta';
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8001';

// Initialize Razorpay
export const initializeRazorpay = () => {
  return new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => {
      resolve(true);
    };
    script.onerror = () => {
      resolve(false);
    };
    document.body.appendChild(script);
  });
};

// Create Razorpay order
export const createRazorpayOrder = async (caseId: number, amount: number = 3000) => {
  const token = localStorage.getItem('token')?.replace(/^\"|\"$/g, '').trim();
  
  if (!token) {
    throw new Error('Authentication required. Please login again.');
  }

  const response = await fetch(`${API_BASE_URL}/payments/create-order`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({
      case_id: caseId,
      amount: amount,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(errorData.detail || 'Failed to create payment order');
    error.detail = errorData.detail;
    throw error;
  }

  return await response.json();
};

// Verify payment
export const verifyPayment = async (paymentData: {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}) => {
  const token = localStorage.getItem('token')?.replace(/^\"|\"$/g, '').trim();
  
  if (!token) {
    throw new Error('Authentication required. Please login again.');
  }

  const response = await fetch(`${API_BASE_URL}/payments/verify`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(paymentData),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const error = new Error(errorData.detail || 'Payment verification failed');
    error.detail = errorData.detail;
    throw error;
  }

  return await response.json();
};

// Open Razorpay checkout
export const openRazorpayCheckout = async (orderData: any, onSuccess: (paymentData: any) => void, onError: (error: any) => void) => {
  const isLoaded = await initializeRazorpay();
  
  if (!isLoaded) {
    onError(new Error('Razorpay SDK failed to load'));
    return;
  }

  const options = {
    key: RAZORPAY_KEY_ID,
    amount: orderData.amount,
    currency: orderData.currency || 'INR',
    name: 'Last Opinion',
    description: 'Medical Second Opinion Consultation',
    order_id: orderData.order_id,
    handler: async (response: any) => {
      try {
        const verificationResult = await verifyPayment({
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_order_id: response.razorpay_order_id,
          razorpay_signature: response.razorpay_signature,
        });
        
        onSuccess(verificationResult);
      } catch (error) {
        onError(error);
      }
    },
    prefill: {
      name: 'Patient',
      email: 'patient@example.com',
    },
    theme: {
      color: '#3B82F6',
    },
    modal: {
      ondismiss: () => {
        onError(new Error('Payment cancelled by user'));
      },
    },
  };

  // @ts-ignore - Razorpay is loaded dynamically
  const razorpay = new window.Razorpay(options);
  razorpay.open();
};

// Declare Razorpay type for TypeScript
declare global {
  interface Window {
    Razorpay: any;
  }
}
